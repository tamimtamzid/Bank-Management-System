package bank;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class datails extends JFrame {

	private Container c;
	private Font f;
	private JTextArea view;
	public static String userid, name , nid,phone;
	
	
	public void initalize(String userid  ) {
		this.userid= userid;
		
		//cheak ob = new cheak();
	//	int line=ob.cheakdetails(userid);
		
		File f = new File("infouser.txt");
		Scanner input;
	
		try {
			input = new Scanner(f);
         
			while (input.hasNext()) {
				
				String s = input.next();
				if (s.equals(userid+"all")) {
					name = input.next();
					nid=input.next();
					phone=input.next();
					
					break;
				
				} 
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	

	
	
	
	private JButton back;

	datails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 30, 1200, 800); // setLocation+setSize
		setTitle("Customer");
		setResizable(false);
		initComponent();
	}

	public void initComponent() {
		c = this.getContentPane();
		c.setLayout(null);
	
		c.setBackground(new Color(72, 173, 107));

		f = new Font("Arial", Font.BOLD, 20);

		


		back = new JButton("back");
		back.setBounds(440, 600, 250, 70);
		back.setFont(new Font("Arial", Font.BOLD, 35));
		back.setForeground(Color.BLACK);
		back.setBackground(Color.getHSBColor(205, 255, 105));

		c.add(back);

		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dashboard ob = new dashboard();
				dispose();
				ob.dashboard1();
			}
		});

		
		view = new JTextArea();
		view.setBounds(350,100,400,400);
		view.setFont(f);
		c.add(view);
		
		view.append("user id : "+userid+"\n");
		view.append("name:"+name+"\n");
		view.append("nid:"+nid+"\n");
		view.append("phone:"+phone+"\n");
		
	
		
			//	view.append("name :"+name+"\n");
			//	view.append("nid :"+nid+"\n");
			//	view.append("phone :"+phone+"\n");
				
				
				
				
				
			
				
				
				
		
		
		
		
	}


	public static void main(String[] args) {
		datails1();
	}

	public static void datails1() {
		datails frame = new datails();
		frame.setVisible(true);
	}
}

