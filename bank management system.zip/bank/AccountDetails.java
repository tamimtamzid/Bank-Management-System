package bank;
public class AccountDetails{
	
	private double Balance;
	private long AccountNumber;
	private String Name;
	private String Address;
	private long Number;
	
	public AccountDetails() {
		
	}

	public AccountDetails(long AccountNumber, String Name, String Address, long Number) {
		Balance = 0.0;
		this.AccountNumber = AccountNumber;
		this.Name = Name;
		this.Address = Address;
		this.Number = Number;
		System.out.println("Account Created Successfully");
	}
	
	public double getBalance() {
		return Balance;
	}

	public void setBalance(double balance) {
		Balance = balance;
	}

	public long getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		AccountNumber = accountNumber;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public long getNumber() {
		return Number;
	}

	public void setNumber(long number) {
		Number = number;
	}
	
	public void deposit(double amount) {
		this.Balance = this.Balance + amount;	
		System.out.println("Amount Deposited Successfully");		
	}
	
	public void withdraw(double amount) throws BankAccountException {
		if(this.Balance >= amount) {
			this.Balance = this.Balance - amount;
			System.out.println("Amount Withdrawn Successfully");
		}else {
			throw new BankAccountException("Could not withdraw : Insufficient balance");
		}	
	}
	
	 public void printBalance(){
		 
    	 System.out.println("Current balance: " + Balance);    	 
     }

	@Override
	public String toString() {
		return "AccountDetails [Balance=" + Balance + ", AccountNumber=" + AccountNumber + ", Name=" + Name
				+ ", Address=" + Address + ", Number=" + Number + "]";
	}		
	 
	 
}

