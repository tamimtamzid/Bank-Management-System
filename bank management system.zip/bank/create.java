package bank;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;



public class create extends JFrame {

	private Container c;
	private Font f;
	private JLabel user;
	private JLabel pass;
	private JLabel cr;

	
	
	
	public JTextField userf;
	private JPasswordField passf;
	private JButton save, clear, back;

	create() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 30, 1200, 800); // setLocation+setSize
		setTitle("Create Accoount");
		setResizable(false);
		initComponent();
	}

	public void initComponent() {
		c = this.getContentPane();
		c.setLayout(null);
		c.setBackground(new Color(72, 173, 107));

		f = new Font("Arial", Font.BOLD, 20);


		user = new JLabel("Username: ");
		user.setBounds(343, 270, 350, 80);
		user.setFont(f);
		c.add(user);

		pass = new JLabel("Password: ");
		pass.setBounds(343, 370, 350, 80);
		pass.setFont(f);
		c.add(pass);

		userf = new JTextField();
		userf.setBounds(450, 290, 290, 45);
		userf.setFont(f);
		c.add(userf);

		passf = new JPasswordField();
		passf.setBounds(450, 380, 290, 45);
		passf.setFont(f);
		c.add(passf);

		save = new JButton("save");
		save.setBounds(650, 480, 250, 70);
		save.setFont(new Font("Arial", Font.BOLD, 35));
		save.setForeground(Color.BLACK);
		save.setBackground(Color.getHSBColor(0,0,100));
		c.add(save);

		clear = new JButton("clear");
		clear.setBounds(300, 480, 250, 70);
		clear.setFont(new Font("Arial", Font.BOLD, 35));
		clear.setForeground(Color.BLACK);
		clear.setBackground(Color.getHSBColor(0,0,100));

		c.add(clear);

		back = new JButton("back");
		back.setBounds(490, 600, 250, 70);
		back.setFont(new Font("Arial", Font.BOLD, 35));
		back.setForeground(Color.BLACK);
		back.setBackground(Color.getHSBColor(0,0,100));

		c.add(back);

		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				welcome ob = new welcome();
				dispose();
				ob.welcome1();
			}
		});

		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				userf.setText("");
				passf.setText("");
			}
		});
		
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cheak obc = new cheak();
				boolean t= obc.cheakcreate(userf.getText());
			
				
				if(t) {
					
				
				
				File file = new File("user.txt");
				
				FileOutputStream fos = null;
				
				try {
					fos = new FileOutputStream(file, true);
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				PrintWriter write = new PrintWriter(fos);
				String s = userf.getText();
				write.append(userf.getText()+ " "+passf.getText());
				write.append("\n");
				infouser ob = new infouser();
				ob.initialize(userf.getText());
				dispose();
				ob.infouser1();
				write.close();
				}
				else {
					JOptionPane.showMessageDialog(null,"This Account number already has been exist, Try another");
					dispose();
					create1();
				}
			}
		});
		
	}


	public static void main(String[] args) {
		create1();
	}

	public static void create1() {
		create frame = new create();
		frame.setVisible(true);
	}
}

