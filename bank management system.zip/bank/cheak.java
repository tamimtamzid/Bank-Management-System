package bank;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class cheak {
	
	
	
	
	public boolean cheakcreate(String str) {
		
		
		File f = new File("user.txt");
		Scanner input;
		int i = 0;
		try {
			input = new Scanner(f);

			while (input.hasNext()) {
				
				String s = input.next();
				if (s.equals(str)) {
					 i=1;
					
					break;
				} 
				
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(i==1) 
			return false ;
			else
				return true;
	}
	public static boolean cheakuser(String str) {
		File f = new File("user.txt");
		int c = 0;
		try {
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			StringBuffer sb = new StringBuffer();
			String line;
			while ((line = br.readLine()) !=null) {
				if (line.equals(str)) {
					c = 1;
					break;
				}
			}

		} catch (Exception e) {
			System.out.println("cheak error");
		}
		if (c == 1)
			return true;
		else
			return false;

}
	
	
	public int cheakbalance(String str) {
		String amount="null";
		
		File f = new File("infouser.txt");
		Scanner input;
		int i = 0;
		try {
			input = new Scanner(f);

			while (input.hasNext()) {
				
				String s = input.next();
				if (s.equals(str +"balance")) {
					 amount = input.next();
					
					break;
				} else
					input.next();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Integer am= Integer.valueOf(s);
		Integer am= Integer.valueOf(amount);
		return am;
	}
	
	
	
	
	
	
	public int cheakdetails(String str) {
		
		
		File f = new File("infouser.txt");
		Scanner input;
		int i = 0;
		try {
			input = new Scanner(f);
         
			while (input.hasNext()) {
				 i++;
				String s = input.next();
				if (s == str+"all") {
					break;
					
				
				} 
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return i;
	}


}
