package bank;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;



	public class dashboard extends JFrame {
	
	
		private JButton deposit;
		private JButton withdraw;
		private JButton checkbalance;
		private JButton viewlist;
		private JButton exit,logout;
		private JLabel bank;
		
		private Font font1;
		private Font font2;
		private JMenu menu1;
		private JMenu menu2;
		private JMenu menu3;
		private JMenuItem item1;
		private JMenuItem item2;
		private JMenuItem item3;
		private JMenuItem item4;
		private JMenuItem item5;
		private JMenuItem item6;
		private JMenuItem item7;
		private JMenuBar menubar1;
		private ImageIcon icons;

		private Container c;
		private Font f;
		private  static int balance ;
		private static String userid;
		public static String name,nid,phone,balance1;
		
//		
//		public static void useridchk(String id) {
//			userid =id;
//			 datails obb =new datails();
//			 obb.initalize(userid);
//			//cheak ob = new cheak();
//			// balance = balance+ ob.cheakbalance(id);
//			}
		public void initiaize(String x) {
			userid = x;
			File f = new File("infouser.txt");
			Scanner input;
		
			try {
				input = new Scanner(f);
	         
				while (input.hasNext()) {
					
					String s = input.next();
					if (s.equals(userid+"all")) {
						name = input.next();
						nid=input.next();
						phone=input.next();
						balance1=input.next();
						
						break;
					
					} 
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			balance = Integer.valueOf(balance1);
		}
		
		
		dashboard() {
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(200, 30, 1200, 800); // setLocation+setSize
			setTitle("Dashboard");
			setResizable(false);
			initComponent();
			
		}

		public void initComponent() {
			c = this.getContentPane();
			c.setLayout(null);
			c.setBackground(new Color(61, 200, 255));
			
			ImageIcon bg = new ImageIcon(getClass().getResource("Dashboard.png"));
			JLabel bgf = new JLabel(bg);
			bgf.setBounds(1, 1, 1200, 800);
			c.add(bgf);

			f = new Font("Arial", Font.BOLD, 20);
			
			
		
			deposit = new JButton();
			withdraw = new JButton();
			checkbalance = new JButton();
			viewlist = new JButton();
			exit = new JButton();
			bank = new JLabel();
			font1 = new Font("Arial" ,font1.BOLD, 15);
			font2 = new Font("Arial" ,font2.BOLD, 10);
			menu1 = new JMenu();
			menu2 = new JMenu();
			menu3 = new JMenu();
			item1 = new JMenuItem();
			item2 = new JMenuItem();
			item3 = new JMenuItem();
			item4 = new JMenuItem();
			item5 = new JMenuItem();
			item6 = new JMenuItem();
			item7 = new JMenuItem();
			menubar1 = new JMenuBar();
			logout = new JButton();
			

			//bank.setText("WELCOME TO BANK OF BANGLADESH");
			//bank.setBounds(140,20,250,50);
			//bank.setFont(font1);
			//c.add(bank);
			
			

			
		
		
			
			deposit.setText("Deposit");
			deposit.setBounds(750, 500,350, 80);
			deposit.setBackground(Color.getHSBColor(0,0,100));
			deposit.setForeground(Color.BLACK);
			deposit.setFont(new Font("Arial", Font.BOLD, 25));
			c.add(deposit);
			
			logout.setText("Log Out");
			logout.setBounds(10, 10,150,25);
			logout.setBackground(Color.getHSBColor(0,0,100));
			logout.setForeground(Color.BLACK);
			logout.setFont(new Font("Arial", Font.BOLD, 25));
			c.add(logout);
			
			
			
			
			
			
			
			
			
			deposit.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            String   depositbal = JOptionPane.showInputDialog("Enter amount");
	             Integer dam= Integer.valueOf(depositbal);
	             balance = balance +dam;
	             JOptionPane.showMessageDialog(null,"Your current balance is "+balance);
	           
	            }
	        });
			
			logout.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            JOptionPane.showMessageDialog(null,"you are now log out");
	             welcome obw = new welcome();
	             dispose();
	             obw.welcome1();
	             
	           
	            }
	        });
			
			withdraw.setText("Withdraw");
			withdraw.setBounds(170, 500,350, 80);
			withdraw.setBackground(Color.getHSBColor(0,0,100));
			withdraw.setForeground(Color.black);
			withdraw.setFont(new Font("Arial", Font.BOLD, 25));
			c.add(withdraw);
		
			
			withdraw.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				
					 String   withdrawbal = JOptionPane.showInputDialog("Enter amount");
		             Integer wam= Integer.valueOf( withdrawbal);
		             if(wam>balance)
		            	 JOptionPane.showMessageDialog(null,"infsufficient Balance . please withdraw less than "+balance);
		             else {
		            	 balance = balance - wam;
		             JOptionPane.showMessageDialog(null,"Your current balance is "+balance);
		             }
				}
		    });
			
			
			
			
			
			
			
			
			
			
			
			
			
			checkbalance.setText("Check Balance");
			checkbalance.setBounds(170, 650, 350, 80);
			checkbalance.setBackground(Color.getHSBColor(0,0,100));
			checkbalance.setForeground(Color.BLACK);
			checkbalance.setFont(new Font("Arial", Font.BOLD, 25));
			c.add(checkbalance);
			checkbalance.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null,"your current balance is "+balance);
				}
		    });
			
			viewlist.setText("Details");
			viewlist.setBounds(750, 650, 350, 80);
			viewlist.setBackground(Color.getHSBColor(0,0,100));
			viewlist.setForeground(Color.BLACK);
			viewlist.setFont(new Font("Arial", Font.BOLD, 25));
			c.add(viewlist);
			
			
			viewlist.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				 datails ob =new datails();
				
				 dispose();
				 ob. datails1();
				 
					
				}
		    });

			

		}


		public static void main(String[] args) {
			dashboard1();
		}

		public static void dashboard1() {
			dashboard frame = new dashboard();
			frame.setVisible(true);
		}
	}



