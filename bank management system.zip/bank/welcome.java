package bank;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class welcome extends JFrame {

	private Container c;
	private JButton create, login;
	private Font f;
	private JLabel l,bgf;
	private ImageIcon bg;



	public welcome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 30, 1200, 800); // setLocation+setSize
		setTitle("Bank Of Bangladesh");
		setResizable(false);
		setFont(new Font("Serif", Font.HANGING_BASELINE, 40));
		initComponent();
	}

	public void initComponent() {

		c = this.getContentPane();
		c.setLayout(null);
		c.setBackground(new Color(61, 200, 255));

	
	
		bg = new ImageIcon(getClass().getResource("BOBcover1.png"));
		bgf= new JLabel(bg);
		bgf.setBounds(1, 1, 1200, 800);
		c.add(bgf);


		create = new JButton("Create New Account");

		create.setBounds(170, 600, 350, 80);
		create.setForeground(Color.BLACK);
		create.setBackground(Color.getHSBColor(0,0,100));
		create.setFont(f);
		create.setFont(new Font("Arial", Font.BOLD, 25));
		c.add(create);

		login = new JButton("Already have an Account");
		login.setBounds(750, 600, 350, 80);
		login.setForeground(Color.BLACK);
		login.setBackground(Color.getHSBColor(0,0,100));
		login.setFont(new Font("Arial", Font.BOLD, 25));
		c.add(login);

		

	

		create.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				create ob = new create();
				dispose();
				ob.create1();
			}
		});
		

		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login ob = new login();
				dispose();
				ob.login1();
			}
		});
		

	}

	public static void welcome1() {
		welcome frame = new welcome();
		frame.setVisible(true);

	}

	

	public static void main(String[] args) {

		welcome1();
	}
}

